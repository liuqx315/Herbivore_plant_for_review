A = imread('Sheep.jpg') ;
B = rgb2gray(A) ;
% imshow(B) ;
C = rescale(B) ;
figure(1) ; imagesc(C) ; colorbar ; impixelinfo ;
D = imbinarize(C,0.7) ;
figure(2) ; imagesc(D) ; colorbar ; impixelinfo ;

MinArea = 50 ;
[PreL,PreNum] = bwlabel(D,4) ; 
PreObj = regionprops(PreL,'Area') ;
PreArea = cat(1,PreObj.Area) ;
[Index1,Index2] = find(PreArea < MinArea) ;
Ltemp = PreL ;
Ltemp(ismember(PreL,Index1)) = 0 ;
PostBIm = Ltemp > 0 ;
figure(3) ; imshow(PostBIm) ; colorbar ; impixelinfo ;
save2pdf('Sheep.pdf',gcf,600) ;
[P1,PreNum] = bwlabel(PostBIm,4) ; 
PreObj = regionprops(P1,'Centroid','EquivDiameter','MajorAxisLength') ;
Position = cat(1,PreObj.Centroid) ;
EquivDiameter = cat(1,PreObj.EquivDiameter) ;
MajorAxisLength = cat(1,PreObj.MajorAxisLength) ;
[mean(EquivDiameter) mean(MajorAxisLength)]
X = Position(:,1) ;
Y = Position(:,2) ;
save('Data.mat','X','Y') ;
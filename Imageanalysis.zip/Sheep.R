rm(list=ls(all=T)) 
library(spatial)
library(spatstat)
library(spatstat)
library(rmatio)

dX=1/35
dat <- read.mat('Data.mat')
Positions=data.frame(dat$X*dX,dat$Y*dX);
names(Positions)[1]="Xr";names(Positions)[2]="Yr";
WBox <- owin(xrange = c(1/35,2500/35),yrange = c(1/35,1677/35))
pp <- as.ppp(Positions,WBox)
K <- Kest(pp,correction="Ripley") # correction=c("border", "isotropic", "Ripley", "translate"),
L <- Lest(pp,correction="Ripley")
#Ld=sqrt(K$iso/pi)-K$r
#plot(K$r,Ld, ylab="L(r)",xlab="Distance (pixel)")
#P=pcf(K, method = "b", spar = 1)
g <- pcf(K,method = "b",spar=1)
#IDMax<- which.max(Ld)
#datout=data.frame(K,Ld,data.frame(P))
L1 <- envelope(pp, Lest, nsim=99, fix.n=TRUE)
#plot(L1)
g1 <- envelope(pp, pcf, nsim=99, fix.n=TRUE)

datout_L=data.frame(L1)
datout_g=data.frame(g1)
write.csv(datout_L, "Lresult.csv", row.names = FALSE)
write.csv(datout_g, "gresult.csv", row.names = FALSE)
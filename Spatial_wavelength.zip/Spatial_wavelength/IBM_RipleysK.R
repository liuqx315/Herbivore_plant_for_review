rm(list=ls(all=T)) 
library(spatial)
library(spatstat)
library(spatstat)
library(rmatio)


path=getwd()
setwd(path)
fname<-dir(paste('dataxy/',sep = ""))
NFile<-length(fname)
fname[1]
dX=1
for (k in seq(1,NFile)) {
	dat <- read.mat(paste('dataxy/',fname[k],sep = ""))
    Positions=data.frame(dat$X*dX,dat$Y*dX);
    names(Positions)[1]="Xr";names(Positions)[2]="Yr";
    WBox <- owin(xrange = c(0,max(Positions$Xr)),yrange = c(0,max(Positions$Yr)))
    pp <- as.ppp(Positions,WBox)    
    K <- Kest(pp,correction="Ripley") # correction=c("border", "isotropic", "Ripley", "translate"),
    Ld=sqrt(K$iso/pi)-K$r
    plot(K$r,Ld, ylab="L(r)",xlab="distiances (m)")
    P=pcf(K, method = "b", spar = 1)
    IDMax<- which.max(Ld)
    datout=data.frame(K,Ld,data.frame(P))    
    write.csv(datout, paste0("dataxy_Gr/DataP_L",sprintf("%06d", k),".csv"), row.names = FALSE)    
  }


FS=18;
fileFolder = fullfile(['dataxy_Gr']);
dirOutput  = dir(fullfile(fileFolder,'*.csv'));
fileNames  = {dirOutput.name}';
numdat  = numel(fileNames);
kk=1;
for k=1:numdat
    datT = importfile(fullfile(fileFolder,fileNames{k}), [2, Inf]) ;
    options = fitoptions('Method', 'NonlinearLeastSquares','StartPoint',[2.0 0.6 -1.0]) ;
    myfittype = fittype('A*sin(w*x)*exp(alpha*x)',...
            'dependent',{'y'},'independent',{'x'},...
            'coefficients',{'A','w','alpha'}) ;
    myfit = fit(datT.r,datT.Ld,myfittype,options) ;
    Omega = myfit.w ; Alpha = myfit.alpha ;
    FitY = sin(Omega .* datT.r) .* exp(Alpha .*datT.r) ;
    xsol = fzero_data(datT.r,FitY,0) ;
    MINID = islocalmin(FitY,'MinSeparation',1,'SamplePoints',datT.r) ;
    ID = find(MINID == 1) ;
	if (isempty(ID)) || (length(xsol) == 1)
        Length(kk,:) = [kk 0 0] ; % 0 means no typical wave length
    else
        Length(kk,:) = [kk 2*datT.r(ID(1)) xsol(2)] ;
    end
	kk = kk+1 ;
end
% plot(datT.r,datT.Ld,datT.r(MINID),datT.Ld(MINID),'rs')  % preview result
%     save(sprintf('Grazing_alpha_4_beta_0.1_0.75_wavelength.mat'),'Length');
save(['Spatial_wavelength.mat'],'Length') ;
 
%%
% load('Model_1_Length.mat') ;
% 
% loglog(Length(:,1),Length(:,2),'o'); hold on
% t=linspace(1e3,9001,1000);
% y=1.8*t.^(0.3);
% loglog(t,y,'--','linewidth',2) ;
% xlim([1 100])
% set(gca,'XScale','log','YScale','log');
% set(gca,'fontsize',FS,'linewidth',2,'xminortick','on','yminortick','on',...
%     'ticklength',[0.025 0.01]);
% set(gca,'FontName','Times'); set(gcf,'Color',[1,1,1]);
% save2pdf('FigModel1',gcf,500);



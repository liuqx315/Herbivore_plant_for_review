% load('DataP.mat') ;
[~,~,T] = size(DataP) ;
for k=1:T
    B3 = repmat(Sdata(:,:,k),4);
    J0 = imresize(B3, 0.25);
    BW=J0>mean(J0(:));
	[X,Y]=find(BW==1);
    save(sprintf(['dataxy_Gr/Time_%06.0f.mat'],k),'X','Y','-v6');
end